from app import manager

if __name__ =="__main__":
        manager.run()